# Playground for Beaver Themer

Blank, simple, no nonsense WordPress theme for building entire website with [**Beaver Themer** plugin](https://www.wpbeaverbuilder.com/beaver-themer/?fla=67). The theme is suitable for experienced users mostly, same as Beaver Themer.

For more information and download please visit https://webmandesign.github.io/playground-for-beaver-themer/

&copy; [WebMan Design](https://www.webmandesign.eu) | Licenseed under [GNU General Public License v3](https://www.gnu.org/licenses/gpl-3.0.html)
