# Playground for Beaver Themer Changelog

## 1.0.0

* Initial release.
